# REST Data Service Sample

## About

This sample demonstrates the capability of the Micro Integrator to perform CRUD operations via a data service using the REST protocol.

This sample contains a Data Service called `RESTDataService` that include data sources and queries required to perform the CRUD operations.

## Setup database to run the sample

1. Create a database and a user with the following details and grant that user access to the database.

```
CREATE DATABASE school_db;
USE school_db;
CREATE USER 'user'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON school_db.* TO 'user'@'localhost';
```

2. Create table and insert some records.

```
CREATE TABLE `students` (
`id` int(10) unsigned NOT NULL AUTO_INCREMENT,
`name` varchar(50) DEFAULT NULL,
`school` varchar(50) DEFAULT NULL,
`grade` varchar(50) DEFAULT NULL,
PRIMARY KEY (`id`)
);
```

```
INSERT INTO students (name, school, grade) VALUES
('Tim', 'Summer School', 7),
('Peter', 'Burnley High School', 10);
```

## Deploying

1. Download and start the latest Micro Integrator server. Refer https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi

2. Open the data service artifact and update the RDBMS datasource in it by replacing the URL, Username and Password values with your database credentials. 
3. Build the sample.
4. Download the mysql-connector-j-8.0.32.jar and add it to the `<MI_HOME>/dropins` folder.
5. Copy the RESTDataService_1.0.0.car from `<PROJECT_WORKSPACE>/target` to `<MI_HOME>/repository/deployment/server/carbonapps` location.

## Running the REST Data Service sample

- curl for create student

```
curl --location --request POST 'http://localhost:8290/services/RESTDataService/student' --header 'Content-Type: application/json' \
--data-raw '{
  "_poststudent": {
    "name" : "Will Smith",
    "school": "Beverly Hills School",
    "grade": 10
  }
}'
```

- curl for read student

```
curl --location --request GET 'http://localhost:8290/services/RESTDataService/student'
```

- curl for update student

```
curl --location --request PUT 'http://localhost:8290/services/RESTDataService/student' --header 'Content-Type: application/json' \
--data-raw '{
  "_putstudent": {
      "id" : 3,
    "name" : "Will Smith",
    "school": "Beverly Hills School",
    "grade": 11
  }
}'
```

- curl for delete student

```
curl --location --request DELETE 'http://localhost:8290/services/RESTDataService/student' --header 'Content-Type: application/json' \
--data-raw '{
  "_deletestudent": {
      "id" : 3
  }
}'
```
