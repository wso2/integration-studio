/*
*  Copyright (c) 2005-2015, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
*
*  WSO2 Inc. licenses this file to you under the Apache License,
*  Version 2.0 (the "License"); you may not use this file except
*  in compliance with the License.
*  You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/

package org.wso2.developerstudio.eclipse.multiple.artifact.project.parent.model;

import java.io.File;

import org.wso2.developerstudio.eclipse.multiple.artifact.project.parent.utils.MultipleArtifactProjectConstants;
import org.wso2.developerstudio.eclipse.platform.core.exception.ObserverFailedException;
import org.wso2.developerstudio.eclipse.platform.core.project.model.ProjectDataModel;

public class MultipleArtifactsProjectModel extends ProjectDataModel {
	
	private File multipleArtifactProjectLocation;
	private String multipleArtifactProjectName;

	public String getMultipleArtifactProjectProjectName() {
		return multipleArtifactProjectName;
	}

	public void setMultipleArtifactProjectProjectName(String analyticsProjectName) {
		this.multipleArtifactProjectName = analyticsProjectName;
	}
	
	public void setMultipleArtifactProjectProjectLocation(File multipleArtifactProjectLocation) {
		this.multipleArtifactProjectLocation=multipleArtifactProjectLocation;
	}
	
	public File getMultipleArtifactProjectProjectLocation() {
		return multipleArtifactProjectLocation;
	}
	
	public Object getModelPropertyValue(String key) {
		Object modelPropertyValue = super.getModelPropertyValue(key);
		if (key.equals(MultipleArtifactProjectConstants.WIZARD_OPTION_MULTIPLE_ARTIFACT_NAME)) {
			modelPropertyValue = getMultipleArtifactProjectProjectName();
		}else if(key.equals(MultipleArtifactProjectConstants.WIZARD_OPTION_MULTIPLE_ARTIFACT_LOCATION)){
			modelPropertyValue = getMultipleArtifactProjectProjectLocation();
		}
		return modelPropertyValue;
	}
	
	public boolean setModelPropertyValue(String key, Object data)
			throws ObserverFailedException {
		boolean returnValue = super.setModelPropertyValue(key, data);
		if (key.equals(MultipleArtifactProjectConstants.WIZARD_OPTION_MULTIPLE_ARTIFACT_LOCATION)) {
			setMultipleArtifactProjectProjectLocation(new File(data.toString()));
		} else if (key.equals(MultipleArtifactProjectConstants.WIZARD_OPTION_MULTIPLE_ARTIFACT_NAME)) {
			setMultipleArtifactProjectProjectName(data.toString());
		}
		return returnValue;
	}

}
