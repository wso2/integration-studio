# REST to SOAP conversion

## About

This sample demonstrates how we can expose an existing SOAP service as a RESTful API.  

This sample consists of a REST API called ‘CityInformationAPI’ and an Endpoint ‘CityLookupEP'.

The API resource is configured with an URI-Template and parameterized to get the ZIP code. A request payload is constructed with a given zip code. Also, ‘SOAPAction’ which is a mandatory header for SOAP 1.1 is set before invoking the endpoint. Once the response is received, it is sent back to the client converting the XML message to a JSON message.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/
2. Build the sample
3. Copy the RESTtoSOAPConversion_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## How to invoke

```
curl --location 'http://localhost:8290/city/lookup/60601' 
```
