/*
 * Copyright (c) 2015, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.wso2.developerstudio.eclipse.perspective.plugin.sample.views;

import java.util.Observable;
import java.util.Observer;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.ui.part.ViewPart;


public class CustomEditorView extends ViewPart implements Observer {
	private TabFolder tabFolder;
	private Label lblNoData;
	private TabItem tabPageProperties;
	private TabItem tabPageTags;
	private TabItem tabPageDependencies;
	private TabItem tabPageComments;
	private TabItem tabPageAssociations;
	private Action actionRefresh;
	private Action actionAddTag;
	private Action actionAddComment;
	private Action actionAddProperty;
	private Action actionAddAssociation;
	private Action actionAddDependency;
	
	
	
	public void createPartControl(Composite parent) {
		tabFolder = new TabFolder(parent, SWT.BORDER);
		tabFolder.setBackground(tabFolder.getDisplay().getSystemColor(
				SWT.COLOR_WHITE));
		createToolbar();
		createTabPages();
		tabFolder.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent arg0) {
				decideToolBarButtons();
			}

			public void widgetSelected(SelectionEvent arg0) {
				decideToolBarButtons();
			}

		});
		lblNoData = new Label(tabFolder, SWT.CENTER);
		lblNoData.setBackground(tabFolder.getBackground());
		decideToolBarButtons();
	}

	private void createTabPages() {

		tabPageProperties = new TabItem(tabFolder, SWT.NULL);
		tabPageProperties.setText("Properties");

		tabPageTags = new TabItem(tabFolder, SWT.NULL);
		tabPageTags.setText("Tags");

		tabPageComments = new TabItem(tabFolder, SWT.NULL);
		tabPageComments.setText("Comments");

		tabPageDependencies = new TabItem(tabFolder, SWT.NULL);
		tabPageDependencies.setText("Dependencies");

		tabPageAssociations = new TabItem(tabFolder, SWT.NULL);
		tabPageAssociations.setText("Associations");
	}
	
	private void decideToolBarButtons() {
		int selectionIndex = tabFolder.getSelectionIndex();
		TabItem item = tabFolder.getItem(selectionIndex);
		if (item == tabPageProperties)
			showToolBarButtons(new Action[] { actionRefresh, actionAddProperty});
		else if (item == tabPageTags)
			showToolBarButtons(new Action[] { actionRefresh, actionAddTag});
		else if (item == tabPageComments)
			showToolBarButtons(new Action[] { actionRefresh, actionAddComment});
		else if (item == tabPageDependencies)
			showToolBarButtons(new Action[] { actionRefresh,
					actionAddDependency});
		else if (item == tabPageAssociations)
			showToolBarButtons(new Action[] { actionRefresh,
					actionAddAssociation});

	}
	
	private void showToolBarButtons(Action[] actions) {
		IToolBarManager mgr = getViewSite().getActionBars().getToolBarManager();
		mgr.removeAll();
		for (Action action : actions) {
			mgr.add(action);
		}
		mgr.update(true);
	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		
	}
	
	private void createToolbar() {
		actionAddProperty = new Action("Edit Properties") {
			public void run() {

			}
		};
		actionAddTag = new Action("Edit Tags") {
			public void run() {
			}
		};
		actionAddComment = new Action("Edit Comments") {
			public void run() {
			}
		};
		actionAddDependency = new Action("Edit Dependencies") {
			public void run() {

			}
		};
		actionAddAssociation = new Action("Edit Associations") {
			public void run() {
			}
		};
		actionRefresh = new Action("Refresh") {
			public void run() {
			}
		};

	}
}
