# Message Filtering Sample

## About

This sample demonstrates how message filtering can be done using the MI based on a request path parameter. The scenario is about a verification service which checks the validity of a phone number.

This sample consists of a Rest API called PhoneVerifyAPI  and an endpoint called PhoneVerifyEP. The API resource is configured with an URI Template which is parameterized to fetch the phone number. The Filter mediator act as a IF-ELSE programming construct that validates whether the phone number contains 10 digits. If the condition is evaluated to true, request is sent to the backend, else an error message is constructed and sent back to the client.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Build the sample
3. Copy the MessageFiltering_1.0.0-SNAPSHOT.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## How to invoke

curl with valid phone number
```
curl --location 'http://localhost:8290/phones/validate/7575449510'
```

curl with invalid phone number
```
curl --location 'http://localhost:8290/phones/validate/75754495'
```