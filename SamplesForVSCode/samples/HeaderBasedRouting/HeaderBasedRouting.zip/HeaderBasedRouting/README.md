# Header Based Routing Sample

## About

This sample demonstrates the routing capability of the Micro Integrator. Routing happens based on a header of the message. The integration scenario is about a service, which performs arithmetic operations. Based on the “operation” header of the message, the message needs to be routed to the relevant service.

This sample consists of an API called CalculatorAPI and two endpoints called CalculatorAddEP, CalculatorDivideEP, which represents the backend services in the MI context. 

Routing happens based on the value of the HTTP header called ‘Operation’.

Switch mediator does the routing by extracting the value of element by using an XPath expression. Then, PayloadFactory mediator is used to construct the message payload required by the backend service.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Build the sample
3. Copy the HeaderBasedRouting_1.0.0-SNAPSHOT.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## How to invoke

curl for add operation
```
curl --location 'http://localhost:8290/calculate' --header 'Operation: Add' --header 'Content-Type: application/xml' \
--data '<ArithmaticOperation>
  <Arg1>10</Arg1>
  <Arg2>25</Arg2>
</ArithmaticOperation>'
```

curl for divide operation
```
curl --location 'http://localhost:8290/calculate' --header 'Operation: Divide' --header 'Content-Type: application/xml' \
--data '<ArithmaticOperation>
  <Arg1>10</Arg1>
  <Arg2>25</Arg2>
</ArithmaticOperation>'
```
