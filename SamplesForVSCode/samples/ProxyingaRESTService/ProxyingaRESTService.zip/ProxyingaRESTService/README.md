# Proxying a REST Service Sample

## About

This sample contains a service, which act as a proxy to an existing RESTful service.

When a client invokes the service, it forwards the message to the backend service without altering its content.

This sample contains a REST API called UserInfoRestAPI which act as the proxy. Also it contains an HTTP endpoint called UsersHttpEP that represents the actual backend service in MI context.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Build the sample
3. Copy the ProxyingaRESTService_1.0.0-SNAPSHOT.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## How to invoke

curl for add operation
```
curl --location 'http://localhost:8290/userInfo/users' --header 'Accept: application/json' 
```

## License
This sample is licensed under the Apache License 2.0.

