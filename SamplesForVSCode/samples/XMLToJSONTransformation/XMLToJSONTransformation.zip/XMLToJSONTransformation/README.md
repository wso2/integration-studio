# XML to JSON Transformation Sample

## About

This sample demonstrates some of the message transformation capabilities of the Micro Integrator.

The API constructs a JSON payload after receiving the request as the actual backend requires a JSON message. But the received request is in XML format. Hence the mediation layer transforms a XML into a JSON by mapping the necessary elements from the request payload. The endpoint returns a JSON message back as the response. Then the JSON response get converted to a XML and responded back to the client.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

3. Build the sample
4. Copy the XMLToJSONTransformation_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## Running the XML to JSON transformation sample

curl for operation
```
curl --location --request POST 'http://localhost:8290/laboratory/users' --header 'Content-Type: application/xml' \
--data-raw '<user>
	<name>Sam</name>
	<job>Scientist</job>
</user>' 
```
