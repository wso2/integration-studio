package client;

import java.rmi.RemoteException;

import client.AccountServiceStub.CheckAccountBalanceResponse;
import client.AccountServiceStub.CheckAccountResponse;
import client.AccountServiceStub.CreateAccountResponse;
import client.AccountServiceStub.CreditAccountResponse;
import client.AccountServiceStub.DebitAccountResponse;

public class AccountServiceClient {

	/**
	 * Change this URL according to your service hosting configuration.
	 */
	public static final String EndPointUrl = "http://localhost:9763/services/AccountService/";

	/**
	 * @param args
	 * @throws RemoteException
	 */
	public static void main(String[] args) throws RemoteException {

		// Creating stub object
		AccountServiceStub serviceStub = new AccountServiceStub(EndPointUrl);

		// Invoke the create account service.
		CreateAccountResponse createAccountResponse = serviceStub
				.createAccount();
		int account_number = createAccountResponse.get_return();
		System.out.println("Account Created Under Account Number :"
				+ createAccountResponse.get_return());
		System.out.println("");
		System.out.println("Verifying Account Existence......");
		System.out.println("");
		// Create the check account request.
		AccountServiceStub.CheckAccount checkAccountRequest = new AccountServiceStub.CheckAccount();
		checkAccountRequest.setAccountNo(account_number);
		serviceStub.checkAccount(checkAccountRequest);

		// Invoke the check account service.
		CheckAccountResponse checkAccountResponse = serviceStub
				.checkAccount(checkAccountRequest);
		System.out.println("Account Existence Verifyied :"
				+ checkAccountResponse.get_return());
		System.out.println("");
		// Create the credit account request.
		AccountServiceStub.CreditAccount creditaccountRequest = new AccountServiceStub.CreditAccount();
		creditaccountRequest.setAccountNo(account_number);
		creditaccountRequest.setAmount(120000);

		// Invoke the credit account service.
		CreditAccountResponse responce = serviceStub
				.creditAccount(creditaccountRequest);

		System.out.println("Account Credited by $120000 :"
				+ responce.get_return());
		System.out.println("");
		// Create check account balance request.
		AccountServiceStub.CheckAccountBalance checkAccountBalanceRequest = new AccountServiceStub.CheckAccountBalance();
		checkAccountBalanceRequest.setAccountNo(account_number);

		// Invoke the check account balance service.
		CheckAccountBalanceResponse accountBalanceResponse = serviceStub
				.checkAccountBalance(checkAccountBalanceRequest);
		System.out.println("Current Account Balance ($):"
				+ accountBalanceResponse.get_return());
		System.out.println("");
		// Create the debit account request.
		AccountServiceStub.DebitAccount debitAccountRequest = new AccountServiceStub.DebitAccount();
		debitAccountRequest.setAccountNo(account_number);
		debitAccountRequest.setAmount(70000);

		// Invoke the debit account service.
		DebitAccountResponse debitAccountResponce = serviceStub
				.debitAccount(debitAccountRequest);

		System.out.println("Account Debited by $70000 :"
				+ debitAccountResponce.get_return());
		System.out.println("");
		CheckAccountBalanceResponse accountBalanceResponse1 = serviceStub
				.checkAccountBalance(checkAccountBalanceRequest);
		System.out.println("Current Account Balance ($):"
				+ accountBalanceResponse1.get_return());

	}

}
