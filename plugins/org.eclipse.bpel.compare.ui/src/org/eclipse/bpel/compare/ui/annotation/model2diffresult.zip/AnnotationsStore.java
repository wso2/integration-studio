package org.eclipse.emf.compare.ui.gef.annotation;

import java.util.Collections;
import java.util.WeakHashMap;

import org.eclipse.emf.compare.diff.metamodel.DiffElement;
import org.eclipse.emf.compare.diff.metamodel.DiffModel;
import org.eclipse.emf.compare.diff.service.DiffService;
import org.eclipse.emf.compare.match.metamodel.MatchModel;
import org.eclipse.emf.compare.match.service.MatchService;
import org.eclipse.emf.ecore.EObject;

public class AnnotationsStore {

	private static AnnotationsStore instance;
	private WeakHashMap<EObject, DiffElement> model2annotation =
		new WeakHashMap<EObject, DiffElement>();
	
	public static synchronized AnnotationsStore getInstance() {
		if (instance == null) {
			instance = new AnnotationsStore();
		}
		return instance;
	}
	
	/**
	 * Compares two models and stores all the changes.
	 * To get the change for certain element use {@link #getAnnotation(EObject)}
	 * 
	 * This function should be used once for given <code>left</code>
	 * and <code>right</code> objects. Next call will override the result of
	 * the previous call.
	 * 
	 * I.e. this function should not be used like that:
	 * annotate(left, right);
	 * annotate(left, right1);
	 * 
	 * @param left
	 * @param right
	 */
	public void annotate(EObject left, EObject right) {
		try {
			MatchModel match = MatchService.doMatch(left, right, 
					Collections.<String, Object> emptyMap());
			DiffModel diff = DiffService.doDiff(match, false);
			AnnotationSwitch as = new AnnotationSwitch();
			model2annotation.putAll(as.getAnnotations(diff, match));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public DiffElement getAnnotation(EObject model) {
		return model2annotation.get(model);
	}
	
}
