
# Kafka Integration

## About

This sample demonstrates the Kafka integration capabilities of the Micro Integrator.

This sample contains a REST API called ‘WeatherDataPublishAPI’, a Kafka inbound endpoint called ‘WeatherDataTransmitInboundEP’ and two Sequences called ‘WeatherDataProcessSeq’ and  ‘WeatherDataErrorSeq’. We are also using the KafkaTransport connector to publish messages to Kafka.

The API receives the HTTP request with JSON payload. Then it publishes to the Kafka topic using the Kafka connector. A response payload is generated with certain information such as topic, partition, offset and send back to client.

Kafka inbound endpoint periodically polls JSON messages in the WeatherDataTopic. It receives available messages in the topic and injects into the sequence. The sequence logs the message.

## Deploying 

1. Download the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Start Kafka server and create a topic named weatherdatatopic by executing following commands in the KAFKA_HOME directory.
- in windows
```
bin\windows\kafka-topics.bat --create --bootstrap-server localhost:9092 --replication-factor 1 --partitions 1 --topic weatherdatatopic

```
- in linux/mac
```
bin/kafka-topics.sh --create --bootstrap-server localhost:9092 --replication-factor 1 --partitions 1 --topic weatherdatatopic
```

3. Add the following jars to <MI_HOME>/lib folder
- kafka-clients-3.5.0.jar                      
- metrics-core-2.2.0.jar                       
- zookeeper-3.6.4.jar
- kafka_2.13-3.5.0.jar                         
- scala-library-2.13.10.jar

4. Navigate to the connector store and search for Kafka. Click on Kafka Inbound Endpoint and download the .jar file by clicking on Download Inbound Endpoint. Add this .jar file also to the lib folder.

5. Copy the RabbitMQIntegration_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.

6. Start the MI server

## How to invoke

curl for operation
```
curl --location 'http://localhost:8290/publishweatherdata' \
--header 'Content-Type: application/json' \
--data '{
   "coord":{
      "lon":-122.09,
      "lat":37.39
   },
   "sys":{
      "type":3,
      "id":168940,
      "message":0.0297,
      "country":"US",
      "sunrise":1427723751,
      "sunset":1427768967
   },
   "weather":[
      {
         "id":800,
         "main":"Clear",
         "description":"Sky is Clear",
         "icon":"01n"
      }
   ],
   "base":"stations",
   "main":{
      "temp":285.68,
      "humidity":74,
      "pressure":1016.8,
      "temp_min":284.82,
      "temp_max":286.48
   },
   "wind":{
      "speed":0.96,
      "deg":285.001
   },
   "clouds":{
      "all":0
   },
   "dt":1427700245,
   "id":0,
   "name":"Mountain View",
   "cod":200
}'
```
