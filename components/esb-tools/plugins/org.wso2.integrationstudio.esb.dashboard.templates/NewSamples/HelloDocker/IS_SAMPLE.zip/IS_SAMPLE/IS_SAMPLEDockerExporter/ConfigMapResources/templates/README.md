## Do not edit these files
These files contains mapping and template details which are used with config mapper.
