# Protocol Switching Sample

## About

This sample demonstrates the protocol switching capability of WSO2 MI. This sample contains a service, which receive messages over the HTTP protocol and deliver over JMS protocol to a downstream service.

This sample includes a REST API called StudentRegistrationAPI, which takes the HTTP request and publishes it to the JMS queue. The StudentQueueEP represents the JMS endpoint with the necessary parameters.

When the request is received to the API, it is publish to a JMS queue through an endpoint. The endpoint does not return a response. OUT_ONLY property in the mediation flow denotes that one way asynchronous invocation. Also the client will receive a ‘202 Accepted’ response as FORCE_SC_ACCEPTED property is set in the mediation flow.

## Deploying 
1. Download and configure the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Build the sample
3. Copy the ProtocolSwitching_1.0.0-SNAPSHOT.car to <MI_HOME>/repository/deployment/server/carbonapps location.
3. Add the following configuration in <MI_HOME>/conf/deployment.toml file to enable the ActiveMQ sender and listener transport.
```
[[transport.jms.sender]]
name = "default"
parameter.initial_naming_factory = "org.apache.activemq.jndi.ActiveMQInitialContextFactory"
parameter.provider_url = "tcp://localhost:61616"
parameter.connection_factory_name = "QueueConnectionFactory"
parameter.connection_factory_type = "queue"
parameter.cache_level = "producer"
```
5. Add the following libraries (available in ACTIVEMQ_HOME/lib) to the <MI_HOME>/libs folder

    If you are using ActiveMQ 5.8.0 or above
    * activemq-broker-5.8.0.jar
    * activemq-client-5.8.0.jar
    * activemq-kahadb-store-5.8.0.jar
    * geronimo-jms_1.1_spec-1.1.1.jar
    * geronimo-j2ee-management_1.1_spec-1.0.1.jar
    * geronimo-jta_1.0.1B_spec-1.0.1.jar
    * hawtbuf-1.9.jar
    * Slf4j-api-1.6.6.jar
    * activeio-core-3.1.4.jar (available in the ACTIVEMQ_HOME/lib/optional directory)

    For Earlier versions of ActiveMQ
    * activemq-core-5.5.1.jar
    * geronimo-j2ee-management_1.0_spec-1.0.jar
    * geronimo-jms_1.1_spec-1.1.1.jar

6. Start the Micro Integrator.

## How to invoke

curl for add operation
```
curl --location 'http://localhost:8290/registerstudent/' --header 'Content-Type: application/json' \
--data '{
    "Student": {
        "Name": "Peter"
    }
}'
```

The published message can be seen from [ActiveMQ Console](http://127.0.0.1:8161/admin/browse.jsp?JMSDestination=StudentQueue). Default value is ‘admin’ for both password and username.

## License
This sample is licensed under the Apache License 2.0.

