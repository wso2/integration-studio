# Content Based Routing Sample

## About

This sample demonstrates the routing capability of MI. Routing happens based on the content of the message payload. The integration scenario is about a service which does arithmetic operations. Based on the operation type, the message needs to be routed to the relevant service.

This sample consists of a REST API called ‘ArithmaticOperationServiceAPI’ which routes the requests based on the content. Also it consists of two endpoints NumberAdditionEP, NumberDivisionEP represent the relevant backend services in the MI context. 

Routing happens based on the value of the ‘Operation’ attribute in the request payload.

Switch mediator does the routing by extracting the value of the attribute by using an json evaluation expression. Then PayloadFactory mediator is used to construct the message payload required by the backend service. Property mediator sets the message type to JSON, so that response will be converted JSON from XML which was returned by the backend services.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Build the sample
3. Copy the ContentBasedRouting_1.0.0-SNAPSHOT.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## How to invoke

curl for add operation
```
curl --location 'http://localhost:8290/arithmaticAPI' --header 'Content-Type: application/json' \
--data '{
   "Operation": "Add",
   "Arg1": "10",
   "Arg2": "25"
}' 
```

curl for divide operation
```
curl --location 'http://localhost:8290/arithmaticAPI' --header 'Content-Type: application/json' \
--data '{
   "Operation": "Divide",
   "Arg1": "25",
   "Arg2": "5"
}'
```


## License
This sample is licensed under the Apache License 2.0.

