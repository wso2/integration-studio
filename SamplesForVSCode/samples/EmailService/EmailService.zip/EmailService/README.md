# Email Service Sample

## About

This sample contains a REST API which exposes email send and retrieve capabilities using the WSO2 email connector.

Here, the send operation uses the SMTP protocol where as the retrieve operation uses the IMAP protocol to connect with mailbox.

This sample contains a REST API called ‘EmailService’ along with ‘smtpsconnection’ and ‘imapsconnection’ local entries. You can invoke respective resource of this API to perform send and retrieve operations with the Email connector.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Open imapsconnection and smtpsconnection local entry artifacts and replace the EMAIL_ADDRESS and PASSWORD values with your email credentials.

3. Build the sample
4. Copy the EmailService_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## Running the email service sample

curl for send operation

```
curl --location --request POST 'http://localhost:8290/email/send' --header 'Content-Type: application/json' \
--data-raw '{
    "from": "your@gmail.com",
    "to": "your@gmail.com",
    "subject": "Sample email",
    "content": "This is the body of the sample email",
    "contentType":"text/plain"
}' 
```

curl for retrieve operation

```
curl --location --request POST 'http://localhost:8290/email/retrieve' --header 'Content-Type: application/json' \
--data-raw '{
    "subjectRegex":"Sample email"
}'
```
