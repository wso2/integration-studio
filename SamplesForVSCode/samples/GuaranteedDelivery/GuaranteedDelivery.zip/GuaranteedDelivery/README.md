# Guaranteed Delivery Sample

## About

This sample demonstrates the ‘Guaranteed Delivery’ or the ‘Fail Safe Delivery’ concept.

This sample consists of a REST API called ‘UserRegistrationAPI’, an Endpoint called ‘UserRegistrationEP, a Message processor called ‘UserRegistrationMP’, a Message store called ‘UserRegistrationMS’ and two Sequences called ‘UserRegistrationErrorSeq’ and ‘UserRegistrationResponseSeq’.

Also, it contains another REST API called ‘MockAPI’ to mimic the backend.

UserRegistrationAPI receives the requests and stores them in the massage store. The message processor periodically polls from the message store and forwards the messages to the specified endpoint. The response return from the endpoint is injected to the response sequence. This payload will be logged and dropped at the end.

## Deploying
1. Start the RabbitMQ broker.
2. Open the Message Store artifact and edit its RabbitMQ credentials accordingly.
3. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

4. Build the sample
5. Copy the GuaranteedDelivery_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## Running the guaranteed delivery sample

curl for operation
```
curl --location --request POST 'http://localhost:8290/registeruserapi' --header 'Content-Type: application/json' \
--data-raw '{
 "id": 1,
 "name": "Leanne Graham",
 "username": "Bret",
 "email": "Sincere@april.biz",
 "address": {
    "street": "Kulas Light",
    "suite": "Apt. 556",
    "city": "Gwenborough",
    "zipcode": "92998-3874",
    "geo": {
     "lat": "-37.3159",
     "lng": "81.1496"
    }
 },
 "phone": "1-770-736-8031 x56442",
 "website": "hildegard.org",
 "company": {
    "name": "Romaguera-Crona",
    "catchPhrase": "Multi-layered client-server neural-net",
    "bs": "harness real-time e-markets"
 }
}' 
```
