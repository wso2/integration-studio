
# RabbitMQ Integration Sample

## About

This sample demonstrates the integration with RabbitMQ over AMQP protocol.

RabbitMQ inbound endpoint periodically polls XML messages in the SalesOrderQueue. It consumes available messages in the queue and injects into the sequence. The sequence logs the message. The endpoint represents the AMQP destination. Proxy service receive HTTP request with XML payload. Then it publishes to the AMQP queue. OUT_ONLY property in the mediation flow denotes a one way asynchronous invocation. Also, the client will receive a ‘202 Accepted’ response as the FORCE_SC_ACCEPTED property is set in the mediation flow.

## Deploying 
1. Start RabbitMQ broker. 

2. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

3. Select the Embedded Micro Integrator Server Configuration Wizard from the toolbar and add the following config to the Edit embedded deployment.toml file section to enable the RabbitMQ sender transport.
```
[transport.rabbitmq]
sender_enable = true
```

4.Download the amqp-client-5.7.0.jar and add it to the Embedded Micro Integrator Server Configuration Wizard's Select libraries section by clicking the plus icon.

5. Build the sample
6. Copy the RabbitMQIntegration_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## How to invoke

curl for operation
```
curl --location --request POST 'http://localhost:8290/services/SalesOrderAddService' --header 'Content-Type: application/xml' \
--data-raw '<Orders>
	<Order>
		<Id>1</Id>
		<Price>100</Price>
	</Order>
</Orders>' 
```
