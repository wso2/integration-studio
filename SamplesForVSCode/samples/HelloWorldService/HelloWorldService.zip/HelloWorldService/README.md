# Hello World Service Sample

This sample demonstrates a simple Hello World service using WSO2 Integration Studio.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Build the sample
3. Copy the HelloWorldService_1.0.0-SNAPSHOT.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## How to invoke
```
curl --location 'http://localhost:8290/HelloWorld' --header 'Accept: application/json' 
```

## How It Works
The HelloWorldService exposes a RESTful API endpoint that responds with a friendly greeting: “Hello, World!”

## License
This sample is licensed under the Apache License 2.0.

