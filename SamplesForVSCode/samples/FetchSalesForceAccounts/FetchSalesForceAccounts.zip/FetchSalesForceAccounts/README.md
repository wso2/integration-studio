# Fetch Salesforce Account sample

## About

This sample demonstrates how we can integrate MI with the Salesforce system.

This sample consists of an API called ‘SalesforceAccountServiceAPI’ which is used to connect with the Salesforce system to retrieve the data relates to salesforce accounts. This API is using the operations provided by the SalesforceREST connector.

When the API is invoked, it connects to the Salesforce via the connector and responds back with the data related to salesforce accounts.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/
2. Click on the 'init' operation in diagram and update the following properties in order to connect to the Salesforce account. Follow these [steps](https://mi.docs.wso2.com/en/latest/includes/reference/connectors/salesforce-connectors/sf-access-token-generation/) to generate the Access Tokens for Salesforce and obtain the following properties.
- accessToken
- refreshToken
- clientSecret
- clientId
- apiUrl
3. Build the sample
4. Copy the FetchSalesForceAccounts_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.

Sample curl
```
curl --location 'http://localhost:8290/salesforceaccountapi'
```