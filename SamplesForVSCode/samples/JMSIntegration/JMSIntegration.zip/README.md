# JMS Integration

## About

This sample demonstrates some of the capabilities in WSO2 MI for integrating with JMS brokers.

This sample contains a REST API called ‘OrderPaymentServiceAPI’, a JMS Inbound Endpoint called ‘OrderPaymentQueueInboundEP’, an Endpoint called ‘OrderPaymentQueueEP’ and two Sequences OrderPaymentQueueProcessSeq and OrderPaymentQueueErrorSeq.

The REST API receives HTTP request with XML payload and then it publishes to the OrderPaymentQueue queue. OUT_ONLY property in the mediation flow denotes the one way asynchronous invocation. Also, the client will receive a ‘202 Accepted’ response as the FORCE_SC_ACCEPTED property is set in the mediation flow.

JMS inbound endpoint periodically polls XML messages in the OrderPaymentQueue. It consumes available messages in the queue and injects them to the sequence. The sequence logs the message. The endpoint represents the JMS destination.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/
2. Start the activeMQ server 
3. Build the sample
4. Add the following configuration to the <MI_HOME>/conf/deployment.toml file
```
[[transport.jms.sender]]
name = "default"
parameter.initial_naming_factory = "org.apache.activemq.jndi.ActiveMQInitialContextFactory"
parameter.provider_url = "tcp://localhost:61616"
parameter.connection_factory_name = "QueueConnectionFactory"
parameter.connection_factory_type = "queue"
parameter.cache_level = "producer"

[[transport.jms.listener]]
name = "myQueueConnectionFactory"
parameter.initial_naming_factory = "org.apache.activemq.jndi.ActiveMQInitialContextFactory"
parameter.provider_url = "tcp://localhost:61616"
parameter.connection_factory_name = "QueueConnectionFactory"
parameter.connection_factory_type = "queue"
```
5. Add the following libraries (available in ACTIVEMQ_HOME/lib) to the <MI_HOME>/lib directory
- activemq-broker-5.8.0.jar
- activemq-client-5.8.0.jar
- activemq-kahadb-store-5.8.0.jar
- geronimo-jms_1.1_spec-1.1.1.jar
- geronimo-j2ee-management_1.1_spec-1.0.1.jar
- geronimo-jta_1.0.1B_spec-1.0.1.jar
- hawtbuf-1.9.jar
- Slf4j-api-1.6.6.jar
- activeio-core-3.1.4.jar (available in the ACTIVEMQ_HOME/lib/optional directory)
6. Copy the JMSIntegration_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## How to invoke 
```
curl --location 'http://localhost:8290/orderpayment' \
--header 'Content-Type: application/json' \
--data '{
    "Payment": {
        "Id": "1",
        "Amount": "100"
    }
}'
```