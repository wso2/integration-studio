/*
 * Copyright (c) 2015, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.wso2.developerstudio.eclipse.perspective.plugin.sample;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

public class SamplePerspective implements IPerspectiveFactory{
	private static final String EDITOR_VIEW_ID = "org.wso2.developerstudio.eclipse.perspective.plugin.sample.editorView";
	public void createInitialLayout(IPageLayout layout) {
		layout.addView(EDITOR_VIEW_ID, IPageLayout.RIGHT, .25f, IPageLayout.ID_EDITOR_AREA);
	    defineActions(layout);
	    defineLayout(layout);
	    layout.setEditorAreaVisible(false);
	}
	public void defineActions(IPageLayout layout) {
	        // Add "new wizards".
	        layout.addNewWizardShortcut("org.eclipse.ui.wizards.new.folder");
	        layout.addNewWizardShortcut("org.eclipse.ui.wizards.new.file");

	        // Add "show views".
	        layout.addShowViewShortcut(IPageLayout.ID_RES_NAV);
	        layout.addShowViewShortcut(IPageLayout.ID_BOOKMARKS);
	        layout.addShowViewShortcut(IPageLayout.ID_OUTLINE);
	        layout.addShowViewShortcut(IPageLayout.ID_PROP_SHEET);
	        layout.addShowViewShortcut(IPageLayout.ID_TASK_LIST);
	}
	public void defineLayout(IPageLayout layout) {
	        // Editors are placed for free.
	        String editorArea = layout.getEditorArea();

	        // Place navigator and outline to left of
	        // editor area.
	        IFolderLayout left =
	                layout.createFolder("left", IPageLayout.LEFT, (float) 0.26, editorArea);
	        left.addView(IPageLayout.ID_RES_NAV);
	        left.addView(IPageLayout.ID_OUTLINE);
	}
}
