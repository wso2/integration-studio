# Exception Handling

## About

This sample demonstrates the exception handling capabilities.

This sample consists of an API called ‘TimeoutAPI’, an Endpoint called ‘DelayHttpEP’ and a Sequence called ‘TimeoutFailureSeq’

The backend service takes around 60 seconds to respond back. The endpoint timeout is set to 30 seconds and upon the timeout, the fault sequence is executed. The sequence logs the proper error and responds back with an error message.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/
2. Build the sample
3. Copy the ExceptionHandling_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.

Sample curl
```
curl --location 'http://localhost:8290/timeout'
```