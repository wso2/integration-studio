# File Transfer Sample

## About

This sample demonstrates some of the file handling capabilities of the Micro Integrator.

This sample contains an Inbound Endpoint called ‘StudentDataFileProcessInboundEP‘ which polls a particular location for available files. Also, it contains two sequences called ‘StudentDataFileProcessSeq‘ and ‘StudentDataFileErrorSeq‘.

The file inbound endpoint is listening on file path specified in the transport.vfs.FileURI parameter. The transport.vfs.FileNamePattern represent the file pattern to process. Once the inbound endpoint read a file successfully, content is injected to the sequence for further mediation. In the sample, ‘StudentDataFileProcessSeq‘ logs the content of the received message.

Once read is successful, the file will be moved to a location defined in the transport.vfs.MoveAfterProcess parameter. If an error occurred while reading, then the file will be moved to the location specified in the transport.vfs.MoveAfterFailure parameter.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Open the Inbound EP artifact and edit its absolute folder paths of the following fields to match the folder names of your local machine.
    - File URI
    - Move After Process
    - Move After Failure

3. Build the sample
4. Copy the FileTransfer_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## Running the file transfer sample

Copy any .csv file to the ‘file:///home/user/in’ directory and you can see the content of the csv file being logged in the MI server console. 

After processing the csv files, the files will be moved to the directory specified in transport.vfs.MoveAfterProcess parameter.
