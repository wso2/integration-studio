# Proxying a SOAP Sample

## About

This sample contains a service which acts as a proxy to an already existing service which exposed over a SOAP API.

When a client invokes the service, it simply forwards the message to the backend service without altering its content.

This sample contains a simple Proxy service called ‘ ProxyForEchoService’ which act as the proxy. Also, it contains an endpoint that represents the actual backend service in the MI context. 

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Build the sample
3. Copy the ProxyingaSOAPService_1.0.0-SNAPSHOT.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## How to invoke

```
curl --location 'http://localhost:8290/services/ProxyForEchoService' \
--header 'SOAPAction: urn:echoString' \
--header 'Content-Type: application/xml' \
--data '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Header/>
    <soapenv:Body>
        <echo:echoString xmlns:echo="http://echo.services.core.carbon.wso2.org">
            <in>Hello</in>
        </echo:echoString>
    </soapenv:Body>
</soapenv:Envelope>'
```


## License
This sample is licensed under the Apache License 2.0.

