package org.wso2.developerstudio.eclipse.multiple.artifact.project.parent.utils;


public enum MultipleArtifactProjectEntryTypes {
	XMLARTIFACT;
}
