package org.wso2.dataservice.validator.sample;

import org.wso2.carbon.dataservices.core.engine.ParamValue; 
import org.wso2.carbon.dataservices.core.validation.ValidationContext; 
import org.wso2.carbon.dataservices.core.validation.ValidationException; 
import org.wso2.carbon.dataservices.core.validation.Validator;

public class NumberValidator implements Validator { 

	public void validate(ValidationContext arg0, String arg1, ParamValue arg2) throws ValidationException { 
		// TODO Implement your logic here 
		
	}
}
