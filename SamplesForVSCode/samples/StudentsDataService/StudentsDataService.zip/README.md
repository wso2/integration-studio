# Students Data Service Sample

## About

This sample demonstrates the capability of the Micro Integrator to perform CRUD operations via a data service using the SOAP protocol.

This sample contains a Data Service called `StudentDataService` that include data sources and queries required to perform the CRUD operations.

## Setup database to run the sample

1. Create a database and a user with the following details and grant that user access to the database.

```
CREATE DATABASE school_db;
USE school_db;
CREATE USER 'user'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON school_db.* TO 'user'@'localhost';
```

2. Create table and insert some records.

```
CREATE TABLE `students` (
`id` int(10) unsigned NOT NULL AUTO_INCREMENT,
`name` varchar(50) DEFAULT NULL,
`school` varchar(50) DEFAULT NULL,
`grade` varchar(50) DEFAULT NULL,
PRIMARY KEY (`id`)
);
```

```
INSERT INTO students (name, school, grade) VALUES
('Tim', 'Summer School', 7),
('Peter', 'Burnley High School', 10);
```

## Deploying 

1. Download and start the latest Micro Integrator server. Refer https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi

2. Open the data service artifact and update the RDBMS datasource in it by replacing the URL, Username and Password values with your database credentials. 
3. Build the sample.
4. Download the mysql-connector-j-8.0.32.jar and add it to the `<MI_HOME>/dropins` folder.
5. Copy the StudentsDataService_1.0.0.car from `<PROJECT_WORKSPACE>/target` to `<MI_HOME>/repository/deployment/server/carbonapps` location.

## Running the Students Data Service sample

- curl for create student operation

```
curl --location --request POST 'http://localhost:8290/services/StudentDataService' \
--header 'SOAPAction: urn:CreateStudents' \
--header 'Content-Type: text/xml' \
--data-raw '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dat="http://ws.wso2.org/dataservice">
    <soapenv:Header/>
    <soapenv:Body>
        <dat:CreateStudents>
            <dat:name>Sam</dat:name>
            <dat:school>Mary College</dat:school>
            <dat:grade>8</dat:grade>
        </dat:CreateStudents>
    </soapenv:Body>
</soapenv:Envelope>'
```

- curl for read student operation

```
curl --location --request POST 'http://localhost:8290/services/StudentDataService' \
--header 'SOAPAction: urn:ReadStudents' \
--header 'Content-Type: text/xml' \
--data-raw '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dat="http://ws.wso2.org/dataservice">
    <soapenv:Header/>
    <soapenv:Body>
        <dat:ReadStudents/>
    </soapenv:Body>
</soapenv:Envelope>'
```

- curl for update student operation

```
curl --location --request POST 'http://localhost:8290/services/StudentDataService' \
--header 'SOAPAction: urn:UpdateStudents' \
--header 'Content-Type: text/xml' \
--data-raw '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dat="http://ws.wso2.org/dataservice">
    <soapenv:Header/>
    <soapenv:Body>
        <dat:UpdateStudents>
            <dat:name>Sam</dat:name>
            <dat:school>Mary College</dat:school>
            <dat:grade>6</dat:grade>
            <dat:id>3</dat:id>
        </dat:UpdateStudents>
    </soapenv:Body>
</soapenv:Envelope>'
```

- curl for delete student operation

```
curl --location --request POST 'http://localhost:8290/services/StudentDataService' \
--header 'SOAPAction: urn:DeleteStudents' \
--header 'Content-Type: text/xml' \
--data-raw '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dat="http://ws.wso2.org/dataservice">
    <soapenv:Header/>
    <soapenv:Body>
        <dat:DeleteStudents>
            <dat:id>3</dat:id>
        </dat:DeleteStudents>
    </soapenv:Body>
</soapenv:Envelope>'
```


