# Periodic Scheduled Tasks

## About

This sample demonstrates the task scheduling capabilities of Micro Integrator.

The scenario is about fetching information related to personal records from a service periodically.

This sample consists of a Scheduled Task called ‘PersonRecordRetrieveTask’, an Endpoint called ‘PersonRecordEP’, and a Sequence called ‘PersonRecordSeq’.

The scheduled task is configured to run five times in 30 seconds time intervals. It injects messages to the sequence and the sequence invokes the endpoint to get the person record.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/
2. Build the sample
3. Copy the PeriodicalScheduledTasks_1.0.0.car to <MI_HOME>/repository/deployment/server/carbonapps location.
